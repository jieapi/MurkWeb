<!doctype html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>后台管理 - <?= e($site['title']) ?></title>
    <?php require dirname(__DIR__) . '/partials/styles.php'; ?>
</head>
<body>
    <main class="shell">
        <nav class="nav">
            <a class="brand" href="/admin">
                <span class="brand-mark">M</span>
                <span>后台管理</span>
            </a>
            <div class="nav-actions">
                <span class="badge success"><?= e($adminName) ?></span>
                <a class="button secondary" href="/">前台测试</a>
                <a class="button secondary" href="/admin/logout">退出</a>
            </div>
        </nav>

        <?php if ($flash): ?>
            <div class="notice <?= e($flash['type']) ?>"><?= e($flash['message']) ?></div>
        <?php endif; ?>
        <?php if ($apiError !== ''): ?>
            <div class="notice error"><?= e($apiError) ?></div>
        <?php endif; ?>

        <section class="hero-copy" style="min-height: auto; margin-bottom: 22px;">
            <h1>加密任务管理</h1>
            <p class="lead">这里需要后台登录，可查看 API 返回的任务、状态和脚本信息。前台测试入口保持公开，方便客户或测试人员提交验证任务。</p>
            <div class="stats">
                <div class="stat">
                    <strong><?= e($tasks['total'] ?? 0) ?></strong>
                    <span>任务总数</span>
                </div>
                <div class="stat">
                    <strong><?= e($scripts['total'] ?? count($scripts['list'] ?? [])) ?></strong>
                    <span>脚本数量</span>
                </div>
                <div class="stat">
                    <strong><?= e($tasks['page'] ?? 1) ?></strong>
                    <span>当前页</span>
                </div>
            </div>
        </section>

        <div class="grid">
            <section class="panel">
                <h2>脚本配置</h2>
                <?php if (empty($scripts['list'])): ?>
                    <div class="empty">暂无脚本数据</div>
                <?php else: ?>
                    <?php foreach (($scripts['list'] ?? []) as $script): ?>
                        <article class="script-card" style="margin-bottom: 12px;">
                            <header>
                                <strong><?= e($script['name'] ?? '') ?></strong>
                                <code><?= e($script['code'] ?? '') ?></code>
                            </header>
                            <div class="muted">版本 <?= e($script['version'] ?? '-') ?>，单价 <?= e($script['price'] ?? '-') ?></div>
                            <?php if (!empty($script['pluginOptions'])): ?>
                                <ul class="option-list">
                                    <?php foreach ($script['pluginOptions'] as $option): ?>
                                        <li><code><?= e($option['key'] ?? '') ?></code> <?= e($option['label'] ?? '') ?> / <?= e($option['type'] ?? '') ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php endif; ?>
                        </article>
                    <?php endforeach; ?>
                <?php endif; ?>
            </section>

            <section class="panel">
                <h2>任务列表</h2>
                <form class="filters" method="get" action="/admin">
                    <div class="field">
                        <label for="scriptName">脚本名</label>
                        <input id="scriptName" name="scriptName" value="<?= e($filters['scriptName']) ?>">
                    </div>
                    <div class="field">
                        <label for="status">状态</label>
                        <select id="status" name="status">
                            <option value="">全部</option>
                            <?php foreach ($statusOptions as $option): ?>
                                <option value="<?= e($option['value'] ?? '') ?>"<?= selected($filters['status'], $option['value'] ?? '') ?>>
                                    <?= e($option['label'] ?? $option['value'] ?? '') ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="field">
                        <label for="ip">IP</label>
                        <input id="ip" name="ip" value="<?= e($filters['ip']) ?>">
                    </div>
                    <div class="field">
                        <label for="startTime">开始时间</label>
                        <input id="startTime" name="startTime" value="<?= e($filters['startTime']) ?>" placeholder="2026-05-01 00:00:00">
                    </div>
                    <div class="field">
                        <label for="endTime">结束时间</label>
                        <input id="endTime" name="endTime" value="<?= e($filters['endTime']) ?>" placeholder="2026-05-18 23:59:59">
                    </div>
                    <button class="button" type="submit">筛选</button>
                    <a class="button secondary" href="/admin">重置</a>
                </form>

                <?php if (empty($tasks['list'])): ?>
                    <div class="empty">暂无任务数据</div>
                <?php else: ?>
                    <div class="table-wrap">
                        <table>
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>文件</th>
                                    <th>脚本</th>
                                    <th>状态</th>
                                    <th>进度</th>
                                    <th>费用</th>
                                    <th>提交时间</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($tasks['list'] as $task): ?>
                                    <tr>
                                        <td><?= e($task['id'] ?? '') ?></td>
                                        <td><?= e($task['fileName'] ?? '') ?></td>
                                        <td><?= e($task['scriptName'] ?? $task['scriptCode'] ?? '') ?></td>
                                        <td><code><?= e($task['status'] ?? '') ?></code></td>
                                        <td><?= e($task['processedCount'] ?? 0) ?> / <?= e($task['fileCount'] ?? 0) ?></td>
                                        <td><?= e($task['actualCost'] ?? $task['estimatedCost'] ?? '-') ?></td>
                                        <td><?= e($task['submitTime'] ?? '-') ?></td>
                                        <td><a href="/admin/tasks/<?= e($task['id'] ?? '') ?>">详情</a></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </section>
        </div>
    </main>
</body>
</html>
