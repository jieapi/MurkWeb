<!doctype html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>后台登录 - <?= e($site['title']) ?></title>
    <?php require dirname(__DIR__) . '/partials/styles.php'; ?>
</head>
<body>
    <main class="login-shell">
        <section class="login-card">
            <a class="brand" href="/">
                <span class="brand-mark">M</span>
                <span><?= e($site['app_name']) ?></span>
            </a>
            <h1 style="margin-top: 24px; font-size: 28px;">后台登录</h1>
            <p class="muted">登录后可查看任务列表、状态和脚本配置。</p>

            <?php if ($flash): ?>
                <div class="notice <?= e($flash['type']) ?>"><?= e($flash['message']) ?></div>
            <?php endif; ?>

            <form method="post" action="/admin/login">
                <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
                <div class="field">
                    <label for="username">账号</label>
                    <input id="username" name="username" autocomplete="username" required>
                </div>
                <div class="field">
                    <label for="password">密码</label>
                    <input id="password" name="password" type="password" autocomplete="current-password" required>
                </div>
                <button class="button" type="submit" style="width: 100%;">登录</button>
            </form>
        </section>
    </main>
</body>
</html>
