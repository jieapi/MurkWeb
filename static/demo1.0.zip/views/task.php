<!doctype html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>任务详情 - <?= e($site['title']) ?></title>
    <?php require __DIR__ . '/partials/styles.php'; ?>
</head>
<body>
    <main class="shell">
        <nav class="nav">
            <a class="brand" href="<?= e($backUrl ?? '/') ?>">
                <span class="brand-mark">M</span>
                <span>任务详情</span>
            </a>
            <div class="nav-actions">
                <a class="button secondary" href="<?= e($backUrl ?? '/') ?>">返回</a>
                <a class="button secondary" href="/admin">后台管理</a>
            </div>
        </nav>

        <?php if ($flash): ?>
            <div class="notice <?= e($flash['type']) ?>"><?= e($flash['message']) ?></div>
        <?php endif; ?>

        <section class="panel">
            <h1>任务 #<?= e($taskId) ?></h1>
            <div class="stats" style="margin-top: 0; margin-bottom: 20px;">
                <div class="stat">
                    <strong><?= e($task['status'] ?? '-') ?></strong>
                    <span>状态</span>
                </div>
                <div class="stat">
                    <strong><?= e($task['processedCount'] ?? 0) ?> / <?= e($task['fileCount'] ?? 0) ?></strong>
                    <span>处理进度</span>
                </div>
                <div class="stat">
                    <strong><?= e($task['actualCost'] ?? $task['estimatedCost'] ?? '-') ?></strong>
                    <span>费用</span>
                </div>
            </div>

            <dl>
                <?php foreach ($task as $key => $value): ?>
                    <dt><?= e($key) ?></dt>
                    <dd>
                        <?php if (is_array($value)): ?>
                            <pre><?= e(json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT)) ?></pre>
                        <?php else: ?>
                            <?= e($value) ?>
                        <?php endif; ?>
                    </dd>
                <?php endforeach; ?>
            </dl>

            <div class="nav-actions" style="margin-top: 18px;">
                <a class="button secondary" href="<?= e($backUrl ?? '/') ?>">返回</a>
                <?php if (!empty($task['downloadUrl'])): ?>
                    <a class="button" href="/tasks/<?= e($taskId) ?>/download">下载加密结果</a>
                <?php endif; ?>
            </div>
        </section>
    </main>
</body>
</html>
