<style>
    :root {
        --bg: #eef2f6;
        --surface: #ffffff;
        --surface-soft: #f8fafc;
        --text: #172033;
        --muted: #667085;
        --line: #d8e0ea;
        --primary: #2563eb;
        --primary-dark: #1d4ed8;
        --success: #027a48;
        --danger: #b42318;
        --warning: #b54708;
        --shadow: 0 18px 45px rgba(31, 41, 55, .10);
    }

    * { box-sizing: border-box; }

    body {
        margin: 0;
        min-height: 100vh;
        background:
            radial-gradient(circle at top left, rgba(37, 99, 235, .14), transparent 30%),
            linear-gradient(180deg, #f8fafc 0%, var(--bg) 100%);
        color: var(--text);
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Microsoft YaHei", sans-serif;
    }

    a { color: var(--primary); text-decoration: none; }
    a:hover { text-decoration: underline; }

    .shell {
        width: min(1180px, calc(100% - 32px));
        margin: 0 auto;
        padding: 30px 0 48px;
    }

    .nav {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 16px;
        margin-bottom: 24px;
    }

    .brand {
        display: flex;
        align-items: center;
        gap: 12px;
        font-weight: 800;
        color: var(--text);
    }

    .brand-mark {
        display: grid;
        place-items: center;
        width: 40px;
        height: 40px;
        border-radius: 8px;
        background: #111827;
        color: #fff;
        font-weight: 900;
    }

    .nav-actions {
        display: flex;
        align-items: center;
        gap: 10px;
        flex-wrap: wrap;
    }

    .hero {
        display: grid;
        grid-template-columns: minmax(0, 1fr) minmax(320px, 430px);
        gap: 22px;
        align-items: stretch;
        margin-bottom: 22px;
    }

    .hero-copy,
    .panel {
        background: rgba(255, 255, 255, .92);
        border: 1px solid rgba(216, 224, 234, .9);
        border-radius: 8px;
        box-shadow: var(--shadow);
    }

    .hero-copy {
        padding: 34px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        min-height: 300px;
    }

    h1, h2, h3 { margin-top: 0; letter-spacing: 0; }
    h1 { margin-bottom: 14px; font-size: 38px; line-height: 1.12; }
    h2 { margin-bottom: 18px; font-size: 20px; }
    h3 { margin-bottom: 10px; font-size: 16px; }

    .lead {
        max-width: 680px;
        margin: 0;
        color: var(--muted);
        font-size: 16px;
        line-height: 1.8;
    }

    .stats {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 12px;
        margin-top: 26px;
    }

    .stat {
        padding: 14px;
        border: 1px solid var(--line);
        border-radius: 8px;
        background: var(--surface-soft);
    }

    .stat strong { display: block; font-size: 22px; }
    .stat span { color: var(--muted); font-size: 13px; }

    .panel { padding: 22px; }
    .section { margin-top: 22px; }

    .grid {
        display: grid;
        grid-template-columns: minmax(320px, 420px) minmax(0, 1fr);
        gap: 18px;
        align-items: start;
    }

    .field { display: flex; flex-direction: column; gap: 7px; margin-bottom: 15px; }
    label { font-size: 13px; font-weight: 800; color: #344054; }

    input, select, textarea {
        width: 100%;
        border: 1px solid var(--line);
        border-radius: 8px;
        padding: 11px 12px;
        background: #fff;
        color: var(--text);
        font: inherit;
        outline: none;
        transition: border-color .15s ease, box-shadow .15s ease;
    }

    textarea {
        min-height: 128px;
        resize: vertical;
        font-family: Consolas, "Courier New", monospace;
        font-size: 13px;
        line-height: 1.6;
    }

    input:focus, select:focus, textarea:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px rgba(37, 99, 235, .14);
    }

    .button {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-height: 40px;
        border: 0;
        border-radius: 8px;
        background: var(--primary);
        color: #fff;
        cursor: pointer;
        font: inherit;
        font-weight: 800;
        padding: 9px 16px;
        text-decoration: none;
        white-space: nowrap;
    }

    .button:hover { background: var(--primary-dark); text-decoration: none; }
    .button.secondary { background: #e8eef6; color: #344054; }
    .button.secondary:hover { background: #dfe7f1; }

    .notice {
        margin-bottom: 16px;
        padding: 12px 14px;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 650;
    }

    .notice.error { background: #fef3f2; border: 1px solid #fecdca; color: var(--danger); }
    .notice.success { background: #ecfdf3; border: 1px solid #abefc6; color: var(--success); }

    .muted { color: var(--muted); font-size: 14px; line-height: 1.65; }
    .empty {
        padding: 24px;
        text-align: center;
        color: var(--muted);
        border: 1px dashed var(--line);
        border-radius: 8px;
        background: var(--surface-soft);
    }

    .scripts {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 14px;
    }

    .script-card {
        border: 1px solid var(--line);
        border-radius: 8px;
        padding: 16px;
        background: #fff;
    }

    .script-card header {
        display: flex;
        justify-content: space-between;
        gap: 10px;
        margin-bottom: 8px;
    }

    code, .badge {
        display: inline-flex;
        align-items: center;
        min-height: 24px;
        padding: 2px 7px;
        border-radius: 999px;
        background: #eef2f7;
        color: #344054;
        font-size: 12px;
        font-family: Consolas, "Courier New", monospace;
    }

    .badge.success { background: #ecfdf3; color: var(--success); }
    .badge.warning { background: #fffaeb; color: var(--warning); }

    .option-list {
        margin: 12px 0 0;
        padding: 0;
        list-style: none;
        color: var(--muted);
        font-size: 13px;
    }

    .option-list li { margin-top: 6px; }

    .dynamic-options {
        display: grid;
        gap: 12px;
        margin-bottom: 16px;
    }

    .option-control {
        border: 1px solid var(--line);
        border-radius: 8px;
        padding: 13px;
        background: var(--surface-soft);
    }

    .option-control .field {
        margin-bottom: 0;
    }

    .switch-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 14px;
    }

    .switch-row input[type="checkbox"] {
        width: 44px;
        height: 24px;
        flex: 0 0 auto;
        accent-color: var(--primary);
    }

    .option-empty {
        padding: 14px;
        border: 1px dashed var(--line);
        border-radius: 8px;
        background: var(--surface-soft);
        color: var(--muted);
        font-size: 14px;
    }

    .modal-backdrop {
        position: fixed;
        inset: 0;
        z-index: 50;
        display: none;
        place-items: center;
        padding: 20px;
        background: rgba(15, 23, 42, .48);
    }

    .modal-backdrop.is-open {
        display: grid;
    }

    .modal {
        width: min(520px, 100%);
        border-radius: 8px;
        border: 1px solid var(--line);
        background: #fff;
        box-shadow: 0 24px 70px rgba(15, 23, 42, .24);
        overflow: hidden;
    }

    .modal-header {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 16px;
        padding: 20px 22px;
        border-bottom: 1px solid var(--line);
    }

    .modal-header h2 {
        margin-bottom: 4px;
    }

    .modal-body {
        padding: 22px;
    }

    .modal-close {
        border: 0;
        width: 34px;
        height: 34px;
        border-radius: 8px;
        background: #eef2f7;
        color: #344054;
        cursor: pointer;
        font-size: 20px;
        line-height: 1;
    }

    .progress-track {
        width: 100%;
        height: 12px;
        border-radius: 999px;
        overflow: hidden;
        background: #e8eef6;
        margin: 16px 0 10px;
    }

    .progress-bar {
        width: 0%;
        height: 100%;
        border-radius: inherit;
        background: linear-gradient(90deg, #2563eb, #0ea5e9);
        transition: width .25s ease;
    }

    .steps {
        display: grid;
        gap: 10px;
        margin: 16px 0 0;
        padding: 0;
        list-style: none;
    }

    .step {
        display: flex;
        align-items: center;
        gap: 10px;
        color: var(--muted);
        font-size: 14px;
    }

    .step::before {
        content: "";
        width: 10px;
        height: 10px;
        border-radius: 999px;
        background: #cbd5e1;
        flex: 0 0 auto;
    }

    .step.is-active {
        color: var(--primary);
        font-weight: 800;
    }

    .step.is-active::before {
        background: var(--primary);
    }

    .step.is-done {
        color: var(--success);
    }

    .step.is-done::before {
        background: var(--success);
    }

    .step.is-error {
        color: var(--danger);
        font-weight: 800;
    }

    .step.is-error::before {
        background: var(--danger);
    }

    .modal-actions {
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
        margin-top: 18px;
    }

    .filters {
        display: grid;
        grid-template-columns: repeat(5, minmax(0, 1fr));
        gap: 10px;
        align-items: end;
        margin-bottom: 14px;
    }

    .table-wrap { overflow-x: auto; }
    table { width: 100%; border-collapse: collapse; font-size: 14px; }
    th, td {
        border-bottom: 1px solid var(--line);
        padding: 12px 9px;
        text-align: left;
        vertical-align: top;
    }
    th { color: #475467; font-size: 12px; white-space: nowrap; }

    .login-shell {
        min-height: 100vh;
        display: grid;
        place-items: center;
        padding: 24px;
    }

    .login-card {
        width: min(420px, 100%);
        background: rgba(255, 255, 255, .94);
        border: 1px solid var(--line);
        border-radius: 8px;
        padding: 28px;
        box-shadow: var(--shadow);
    }

    dl {
        display: grid;
        grid-template-columns: 170px minmax(0, 1fr);
        margin: 0;
        border-top: 1px solid var(--line);
    }

    dt, dd {
        margin: 0;
        padding: 12px 8px;
        border-bottom: 1px solid var(--line);
        word-break: break-all;
    }

    dt { color: var(--muted); font-weight: 800; }
    pre { margin: 0; white-space: pre-wrap; }

    @media (max-width: 980px) {
        .hero, .grid { grid-template-columns: 1fr; }
        .scripts { grid-template-columns: repeat(2, minmax(0, 1fr)); }
        .filters { grid-template-columns: repeat(2, minmax(0, 1fr)); }
    }

    @media (max-width: 640px) {
        .shell { width: min(100% - 20px, 1180px); padding-top: 18px; }
        .nav { align-items: flex-start; flex-direction: column; }
        .hero-copy, .panel { padding: 18px; }
        h1 { font-size: 30px; }
        .stats, .scripts, .filters { grid-template-columns: 1fr; }
        dl { grid-template-columns: 1fr; }
        dt { border-bottom: 0; padding-bottom: 2px; }
        dd { padding-top: 2px; }
    }
</style>
