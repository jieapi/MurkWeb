<!doctype html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($site['title']) ?></title>
    <meta name="keywords" content="<?= e($site['keywords']) ?>">
    <meta name="description" content="<?= e($site['description']) ?>">
    <?php require __DIR__ . '/partials/styles.php'; ?>
</head>
<body>
    <main class="shell">
        <nav class="nav">
            <a class="brand" href="/">
                <span class="brand-mark">M</span>
                <span><?= e($site['app_name']) ?></span>
            </a>
            <div class="nav-actions">
                <a class="button secondary" href="/admin">后台管理</a>
            </div>
        </nav>

        <?php if ($flash): ?>
            <div class="notice <?= e($flash['type']) ?>"><?= e($flash['message']) ?></div>
        <?php endif; ?>
        <?php if ($apiError !== ''): ?>
            <div class="notice error"><?= e($apiError) ?></div>
        <?php endif; ?>

        <section class="hero">
            <div class="hero-copy">
                <h1>PHP 源码加密测试</h1>
                <p class="lead">选择加密脚本，上传 PHP 文件或 ZIP 源码包，直接调用 MurkPHP 开放 API 创建测试任务。前台无需登录，适合快速验证加密流程。</p>
                <div class="stats">
                    <div class="stat">
                        <strong><?= e($scripts['total'] ?? count($scripts['list'] ?? [])) ?></strong>
                        <span>可用脚本</span>
                    </div>
                    <div class="stat">
                        <strong>PHP / ZIP</strong>
                        <span>支持文件</span>
                    </div>
                    <div class="stat">
                        <strong>API</strong>
                        <span>实时提交</span>
                    </div>
                </div>
            </div>

            <section class="panel">
                <h2>开始测试</h2>
                <form id="encryptForm" method="post" action="/encrypt/upload" enctype="multipart/form-data">
                    <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
                    <div class="field">
                        <label for="scriptCode">加密脚本</label>
                        <select id="scriptCode" name="scriptCode" required>
                            <option value="">请选择脚本</option>
                            <?php foreach (($scripts['list'] ?? []) as $script): ?>
                                <option value="<?= e($script['code'] ?? '') ?>">
                                    <?= e(($script['name'] ?? '') . ' / ' . ($script['code'] ?? '')) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="field">
                        <label for="source">源码文件</label>
                        <input id="source" name="source" type="file" accept=".php,.zip" required>
                        <div class="muted">请上传待加密 PHP 文件或 ZIP 源码包。</div>
                    </div>
                    <div class="field">
                        <label>加密选项</label>
                        <div id="dynamicOptions" class="dynamic-options">
                            <div class="option-empty">选择加密脚本后显示可配置选项。</div>
                        </div>
                    </div>
                    <button id="submitButton" class="button" type="submit">提交测试任务</button>
                </form>
            </section>
        </section>

    </main>

    <div id="encryptModal" class="modal-backdrop" aria-hidden="true">
        <section class="modal" role="dialog" aria-modal="true" aria-labelledby="modalTitle">
            <div class="modal-header">
                <div>
                    <h2 id="modalTitle">加密任务</h2>
                    <div id="modalSubtitle" class="muted">正在准备上传源码。</div>
                </div>
                <button id="modalClose" class="modal-close" type="button" aria-label="关闭">×</button>
            </div>
            <div class="modal-body">
                <div class="progress-track">
                    <div id="progressBar" class="progress-bar"></div>
                </div>
                <div id="progressText" class="muted">0%</div>

                <ul class="steps">
                    <li id="stepUpload" class="step">上传源码</li>
                    <li id="stepCreate" class="step">提交加密任务</li>
                    <li id="stepEncrypt" class="step">正在加密</li>
                    <li id="stepDone" class="step">加密完成</li>
                </ul>

                <div id="taskSummary" class="muted" style="margin-top: 16px;"></div>
                <div class="modal-actions">
                    <a id="detailButton" class="button secondary" href="#" style="display: none;">查看详情</a>
                    <a id="downloadButton" class="button" href="#" style="display: none;">下载加密结果</a>
                </div>
            </div>
        </section>
    </div>

    <script type="application/json" id="scriptOptionsData"><?=
        json_encode(
            $scripts['list'] ?? [],
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
        )
    ?></script>
    <script>
        const scripts = JSON.parse(document.getElementById('scriptOptionsData').textContent || '[]');
        const scriptSelect = document.getElementById('scriptCode');
        const optionsBox = document.getElementById('dynamicOptions');
        const form = document.getElementById('encryptForm');
        const submitButton = document.getElementById('submitButton');
        const modal = document.getElementById('encryptModal');
        const modalClose = document.getElementById('modalClose');
        const modalSubtitle = document.getElementById('modalSubtitle');
        const progressBar = document.getElementById('progressBar');
        const progressText = document.getElementById('progressText');
        const taskSummary = document.getElementById('taskSummary');
        const detailButton = document.getElementById('detailButton');
        const downloadButton = document.getElementById('downloadButton');
        const stepEls = {
            upload: document.getElementById('stepUpload'),
            create: document.getElementById('stepCreate'),
            encrypt: document.getElementById('stepEncrypt'),
            done: document.getElementById('stepDone'),
        };
        let pollTimer = null;

        const escapeHtml = (value) => String(value ?? '')
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;')
            .replaceAll("'", '&#039;');

        const normalizeDefault = (value, type) => {
            if (value === undefined || value === null) {
                return type === 'boolean' ? false : '';
            }

            if (type === 'json' && typeof value !== 'string') {
                return JSON.stringify(value, null, 2);
            }

            return value;
        };

        const helpText = (option) => {
            const key = escapeHtml(option.key || '');
            const type = escapeHtml(option.type || 'text');
            return `<div class="muted">字段：<code>${key}</code>，类型：${type}</div>`;
        };

        const hiddenType = (option) => {
            const key = escapeHtml(option.key || '');
            const type = escapeHtml(option.type || 'text');
            return `<input type="hidden" name="option_types[${key}]" value="${type}">`;
        };

        const renderInput = (option) => {
            const key = escapeHtml(option.key || '');
            const label = escapeHtml(option.label || option.key || '选项');
            const type = option.type || 'text';
            const value = escapeHtml(normalizeDefault(option.default, type));

            if (type === 'boolean') {
                const checked = normalizeDefault(option.default, type) ? ' checked' : '';
                return `
                    <div class="option-control">
                        ${hiddenType(option)}
                        <input type="hidden" name="options[${key}]" value="0">
                        <div class="switch-row">
                            <div>
                                <label for="option_${key}">${label}</label>
                                ${helpText(option)}
                            </div>
                            <input id="option_${key}" type="checkbox" name="options[${key}]" value="1"${checked}>
                        </div>
                    </div>
                `;
            }

            if (type === 'select') {
                const choices = Array.isArray(option.options) ? option.options : [];
                const selectedValue = String(normalizeDefault(option.default, type));
                const options = choices.map((choice) => {
                    const choiceValue = String(choice.value ?? '');
                    const selected = choiceValue === selectedValue ? ' selected' : '';
                    return `<option value="${escapeHtml(choiceValue)}"${selected}>${escapeHtml(choice.label ?? choiceValue)}</option>`;
                }).join('');

                return `
                    <div class="option-control">
                        ${hiddenType(option)}
                        <div class="field">
                            <label for="option_${key}">${label}</label>
                            <select id="option_${key}" name="options[${key}]">${options}</select>
                            ${helpText(option)}
                        </div>
                    </div>
                `;
            }

            if (type === 'textarea' || type === 'json') {
                return `
                    <div class="option-control">
                        ${hiddenType(option)}
                        <div class="field">
                            <label for="option_${key}">${label}</label>
                            <textarea id="option_${key}" name="options[${key}]" spellcheck="false">${value}</textarea>
                            ${helpText(option)}
                        </div>
                    </div>
                `;
            }

            if (type === 'file') {
                return `
                    <div class="option-control">
                        ${hiddenType(option)}
                        <div class="field">
                            <label for="option_${key}">${label}</label>
                            <input id="option_${key}" name="options[${key}]" type="text" value="${value}" placeholder="请输入文件标识或路径">
                            <div class="muted">开放 API 的任务提交接口只接收 options 对象，这里按字符串值提交。</div>
                        </div>
                    </div>
                `;
            }

            const inputType = ['password', 'number'].includes(type) ? type : 'text';
            return `
                <div class="option-control">
                    ${hiddenType(option)}
                    <div class="field">
                        <label for="option_${key}">${label}</label>
                        <input id="option_${key}" name="options[${key}]" type="${inputType}" value="${value}">
                        ${helpText(option)}
                    </div>
                </div>
            `;
        };

        const renderOptions = () => {
            const selectedScript = scripts.find((script) => String(script.code || '') === scriptSelect.value);
            const options = selectedScript && Array.isArray(selectedScript.pluginOptions)
                ? selectedScript.pluginOptions
                : [];

            if (options.length === 0) {
                optionsBox.innerHTML = '<div class="option-empty">当前脚本暂无可配置选项。</div>';
                return;
            }

            optionsBox.innerHTML = options.map(renderInput).join('');
        };

        scriptSelect.addEventListener('change', renderOptions);
        renderOptions();

        const openModal = () => {
            modal.classList.add('is-open');
            modal.setAttribute('aria-hidden', 'false');
        };

        const closeModal = () => {
            modal.classList.remove('is-open');
            modal.setAttribute('aria-hidden', 'true');
            if (pollTimer) {
                clearTimeout(pollTimer);
                pollTimer = null;
            }
        };

        const setProgress = (percent, text = '') => {
            const normalized = Math.max(0, Math.min(100, Number(percent) || 0));
            progressBar.style.width = `${normalized}%`;
            progressText.textContent = text || `${normalized}%`;
        };

        const setSteps = (active, done = [], error = '') => {
            Object.entries(stepEls).forEach(([key, el]) => {
                el.classList.toggle('is-active', key === active);
                el.classList.toggle('is-done', done.includes(key));
                el.classList.toggle('is-error', key === error);
            });
        };

        const setError = (message, step = '') => {
            modalSubtitle.textContent = message;
            taskSummary.textContent = '';
            setSteps('', [], step);
            submitButton.disabled = false;
        };

        const readJson = async (response) => {
            const payload = await response.json().catch(() => null);
            if (!payload || payload.ok !== true) {
                throw new Error(payload?.message || '请求失败，请稍后重试。');
            }
            return payload;
        };

        const renderTaskStatus = (data) => {
            const task = data.task || {};
            const status = data.status || '-';
            const processed = data.processedCount ?? 0;
            const failed = data.failedCount ?? 0;
            const total = data.fileCount ?? 0;
            const fileName = task.fileName || '源码文件';
            taskSummary.textContent = `${fileName}，状态：${status}，进度：${processed}/${total}，失败：${failed}`;
        };

        const pollTask = (taskId) => {
            fetch(`/encrypt/tasks/${encodeURIComponent(taskId)}/status`, {
                headers: { 'Accept': 'application/json' },
            })
                .then(readJson)
                .then((payload) => {
                    const data = payload.data || {};
                    const progress = data.progress ?? 0;
                    setProgress(progress, `${progress}%`);
                    renderTaskStatus(data);

                    if (data.isSuccess) {
                        modalSubtitle.textContent = '加密成功，可以下载结果。';
                        setSteps('', ['upload', 'create', 'encrypt', 'done']);
                        downloadButton.href = data.downloadUrl || `/tasks/${encodeURIComponent(taskId)}/download`;
                        downloadButton.style.display = 'inline-flex';
                        detailButton.href = `/tasks/${encodeURIComponent(taskId)}`;
                        detailButton.style.display = 'inline-flex';
                        submitButton.disabled = false;
                        return;
                    }

                    if (data.isFinished) {
                        modalSubtitle.textContent = '任务已结束，但未成功完成。';
                        setSteps('', ['upload', 'create'], 'encrypt');
                        detailButton.href = `/tasks/${encodeURIComponent(taskId)}`;
                        detailButton.style.display = 'inline-flex';
                        submitButton.disabled = false;
                        return;
                    }

                    modalSubtitle.textContent = '正在加密，请稍候。';
                    setSteps('encrypt', ['upload', 'create']);
                    pollTimer = setTimeout(() => pollTask(taskId), 2000);
                })
                .catch((error) => {
                    setError(error.message, 'encrypt');
                    detailButton.href = `/tasks/${encodeURIComponent(taskId)}`;
                    detailButton.style.display = 'inline-flex';
                });
        };

        form.addEventListener('submit', async (event) => {
            event.preventDefault();

            if (!form.reportValidity()) {
                return;
            }

            submitButton.disabled = true;
            detailButton.style.display = 'none';
            downloadButton.style.display = 'none';
            taskSummary.textContent = '';
            openModal();
            setProgress(8, '正在上传源码...');
            setSteps('upload');
            modalSubtitle.textContent = '正在上传源码，请稍候。';

            try {
                const uploadPayload = await fetch('/encrypt/upload', {
                    method: 'POST',
                    body: new FormData(form),
                    headers: { 'Accept': 'application/json' },
                }).then(readJson);

                const uploadData = uploadPayload.data || {};
                if (!uploadData.fileId) {
                    throw new Error('上传成功但没有返回 fileId。');
                }

                modalSubtitle.textContent = '上传成功，正在提交加密任务。';
                setProgress(35, '上传成功');
                setSteps('create', ['upload']);
                taskSummary.textContent = `文件数：${uploadData.fileCount ?? '-'}，预估费用：${uploadData.totalPrice ?? '-'}`;

                const taskForm = new FormData(form);
                taskForm.delete('source');
                taskForm.set('fileId', uploadData.fileId);

                const taskPayload = await fetch('/encrypt/tasks', {
                    method: 'POST',
                    body: taskForm,
                    headers: { 'Accept': 'application/json' },
                }).then(readJson);

                const taskId = taskPayload.data?.taskId;
                if (!taskId) {
                    throw new Error('任务已提交但没有返回任务 ID。');
                }

                modalSubtitle.textContent = '任务提交成功，正在加密。';
                setProgress(45, '正在加密...');
                setSteps('encrypt', ['upload', 'create']);
                detailButton.href = `/tasks/${encodeURIComponent(taskId)}`;
                detailButton.style.display = 'inline-flex';
                pollTask(taskId);
            } catch (error) {
                const activeStep = stepEls.create.classList.contains('is-active') ? 'create' : 'upload';
                setError(error.message, activeStep);
            }
        });

        modalClose.addEventListener('click', closeModal);
    </script>
</body>
</html>
