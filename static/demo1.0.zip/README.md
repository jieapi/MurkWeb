# MurkPHP 加密测试后台

一个基于 PHP 的 MurkPHP 开放 API 加密测试页面，支持前台免登录提交加密测试，后台登录查看任务和脚本信息。

## 目录结构

```text
public/              对外访问目录，只保留入口 index.php
src/                 应用代码
views/               页面模板
.env                 本地环境配置
.env.example         环境配置示例
start.bat            Windows 启动脚本
```

## 配置

复制 `.env.example` 为 `.env`，然后设置 API Token 和后台账号：

```env
MURK_API_BASE_URL="https://api.murk.top"
MURK_API_TOKEN="你的 API Token"

ADMIN_USERNAME="admin"
ADMIN_PASSWORD="admin123"
```

## 启动

Windows 下直接执行：

```bat
start.bat
```

默认访问地址：

```text
http://127.0.0.1:8000
```

## 页面路径

```text
/                 前台加密测试，无需登录
/admin            后台管理，需要登录
/admin/login      后台登录
/tasks/{id}       前台任务详情
/admin/tasks/{id} 后台任务详情
```

## 功能

- 查询可用加密脚本
- 根据脚本选项渲染输入框、选择框、开关等控件
- 上传 PHP 文件或 ZIP 源码包
- 弹窗显示上传和加密进度
- 轮询任务状态
- 加密成功后显示下载按钮
- 后台登录后查看任务列表和任务详情

## 依赖

```bash
composer install
```

已使用：

- `nikic/fast-route`
- `vlucas/phpdotenv`
