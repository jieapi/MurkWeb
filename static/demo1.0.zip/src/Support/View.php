<?php
declare(strict_types=1);

namespace App\Support;

use RuntimeException;

final class View
{
    public function __construct(
        private readonly string $basePath,
        private readonly array $site,
    ) {
    }

    public function render(string $template, array $data = []): string
    {
        $file = $this->basePath . '/' . ltrim($template, '/') . '.php';
        if (!is_file($file)) {
            throw new RuntimeException('视图不存在：' . $template);
        }

        $site = $this->site;
        extract($data, EXTR_SKIP);

        ob_start();
        require $file;

        return (string)ob_get_clean();
    }
}
