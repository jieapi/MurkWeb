<?php
declare(strict_types=1);

namespace App\Support;

use App\Config;

final class Auth
{
    public function __construct(private readonly Config $config)
    {
    }

    public function check(): bool
    {
        return !empty($_SESSION['admin_logged_in']);
    }

    public function attempt(string $username, string $password): bool
    {
        $passed = hash_equals($this->config->adminUsername(), $username)
            && hash_equals($this->config->adminPassword(), $password);

        if ($passed) {
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_username'] = $username;
        }

        return $passed;
    }

    public function logout(): void
    {
        unset($_SESSION['admin_logged_in'], $_SESSION['admin_username']);
    }
}
