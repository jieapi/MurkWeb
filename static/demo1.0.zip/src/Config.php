<?php
declare(strict_types=1);

namespace App;

final class Config
{
    public function __construct(private readonly array $values)
    {
    }

    public function string(string $key, string $default = ''): string
    {
        $value = $_ENV[$key] ?? $_SERVER[$key] ?? $this->values[$key] ?? $default;

        return trim((string)$value);
    }

    public function site(): array
    {
        return [
            'app_name' => $this->string('APP_NAME', 'MurkPHP'),
            'title' => $this->string('SITE_TITLE', 'MurkPHP 加密后台'),
            'keywords' => $this->string('SITE_KEYWORDS', 'MurkPHP,PHP加密'),
            'description' => $this->string('SITE_DESCRIPTION', 'MurkPHP 开放 API 加密对接后台'),
        ];
    }

    public function apiBaseUrl(): string
    {
        return rtrim($this->string('MURK_API_BASE_URL', 'https://api.murk.top'), '/');
    }

    public function apiToken(): string
    {
        return $this->string('MURK_API_TOKEN');
    }

    public function adminUsername(): string
    {
        return $this->string('ADMIN_USERNAME', 'admin');
    }

    public function adminPassword(): string
    {
        return $this->string('ADMIN_PASSWORD', 'admin123');
    }
}
