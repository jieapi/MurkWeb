<?php
declare(strict_types=1);

namespace App\Controller;

use App\Http\Request;
use App\Http\Response;
use App\Murk\MurkApiClient;
use App\Murk\MurkApiException;
use App\Support\Csrf;
use App\Support\Flash;
use App\Support\View;

final class FrontController
{
    public function __construct(
        private readonly MurkApiClient $client,
        private readonly View $view,
    ) {
    }

    public function index(Request $request): void
    {
        $scripts = ['list' => [], 'total' => 0, 'page' => 1, 'limit' => 50];
        $apiError = '';

        if ($this->client->hasToken()) {
            try {
                $scripts = $this->client->listScripts();
            } catch (MurkApiException $e) {
                $apiError = $e->getMessage();
            }
        } else {
            $apiError = '请先在 .env 中设置 MURK_API_TOKEN。';
        }

        Response::html($this->view->render('front', [
            'apiError' => $apiError,
            'flash' => Flash::pull(),
            'scripts' => $scripts,
            'csrfToken' => Csrf::token(),
        ]));
    }

    public function create(Request $request): void
    {
        if (!Csrf::validate((string)$request->post('csrf_token', ''))) {
            Response::json(['ok' => false, 'message' => '页面已过期，请刷新后重试。'], 419);
            return;
        }

        $scriptCode = trim((string)$request->post('scriptCode', ''));
        $fileId = trim((string)$request->post('fileId', ''));
        [$options, $optionError] = $this->buildOptions(
            $request->post('options', []),
            $request->post('option_types', []),
        );

        if ($scriptCode === '') {
            Response::json(['ok' => false, 'message' => '请选择加密脚本。'], 422);
            return;
        }

        if ($fileId === '') {
            Response::json(['ok' => false, 'message' => '缺少上传返回的 fileId。'], 422);
            return;
        }

        if ($optionError !== '') {
            Response::json(['ok' => false, 'message' => $optionError], 422);
            return;
        }

        try {
            $task = $this->client->createTask($scriptCode, $fileId, $options);
            $taskId = (string)($task['taskId'] ?? $task['id'] ?? '');

            Response::json([
                'ok' => true,
                'message' => '加密任务已提交。',
                'data' => [
                    'taskId' => $taskId,
                    'task' => $task,
                ],
            ]);
        } catch (MurkApiException $e) {
            Response::json(['ok' => false, 'message' => $e->getMessage()], 502);
        }
    }

    public function upload(Request $request): void
    {
        if (!Csrf::validate((string)$request->post('csrf_token', ''))) {
            Response::json(['ok' => false, 'message' => '页面已过期，请刷新后重试。'], 419);
            return;
        }

        $scriptCode = trim((string)$request->post('scriptCode', ''));
        if ($scriptCode === '') {
            Response::json(['ok' => false, 'message' => '请选择加密脚本。'], 422);
            return;
        }

        try {
            $upload = $this->client->uploadSource($scriptCode, $request->file('source') ?? []);
            Response::json([
                'ok' => true,
                'message' => '源码上传成功。',
                'data' => $upload,
            ]);
        } catch (MurkApiException $e) {
            Response::json(['ok' => false, 'message' => $e->getMessage()], 502);
        }
    }

    public function status(Request $request, array $vars): void
    {
        $taskId = (string)($vars['id'] ?? '');

        try {
            $task = $this->client->getTask($taskId);
            $fileCount = max(0, (int)($task['fileCount'] ?? 0));
            $processedCount = max(0, (int)($task['processedCount'] ?? 0));
            $failedCount = max(0, (int)($task['failedCount'] ?? 0));
            $doneCount = min($fileCount, $processedCount + $failedCount);
            $progress = $fileCount > 0 ? (int)floor(($doneCount / $fileCount) * 100) : 0;
            $status = (string)($task['status'] ?? '');

            if ($status === 'success') {
                $progress = 100;
            }

            Response::json([
                'ok' => true,
                'message' => '任务状态已更新。',
                'data' => [
                    'task' => $task,
                    'status' => $status,
                    'progress' => $progress,
                    'processedCount' => $processedCount,
                    'failedCount' => $failedCount,
                    'fileCount' => $fileCount,
                    'isFinished' => in_array($status, ['success', 'failed', 'cancelled'], true),
                    'isSuccess' => $status === 'success',
                    'downloadUrl' => !empty($task['downloadUrl']) ? '/tasks/' . rawurlencode($taskId) . '/download' : '',
                ],
            ]);
        } catch (MurkApiException $e) {
            Response::json(['ok' => false, 'message' => $e->getMessage()], 502);
        }
    }

    public function show(Request $request, array $vars): void
    {
        $taskId = (string)($vars['id'] ?? '');

        try {
            Response::html($this->view->render('task', [
                'task' => $this->client->getTask($taskId),
                'taskId' => $taskId,
                'flash' => Flash::pull(),
                'backUrl' => '/',
            ]));
        } catch (MurkApiException $e) {
            Flash::put('error', $e->getMessage());
            Response::redirect('/');
        }
    }

    public function download(Request $request, array $vars): void
    {
        $taskId = (string)($vars['id'] ?? '');

        try {
            $task = $this->client->getTask($taskId);
            $downloadUrl = $this->client->downloadUrl($task);

            if ($downloadUrl === null) {
                throw new MurkApiException('当前任务暂无可用下载地址。');
            }

            Response::redirect($downloadUrl);
        } catch (MurkApiException $e) {
            Flash::put('error', $e->getMessage());
            Response::redirect('/tasks/' . rawurlencode($taskId));
        }
    }

    private function buildOptions(mixed $values, mixed $types): array
    {
        if (!is_array($values)) {
            return [[], ''];
        }

        $types = is_array($types) ? $types : [];
        $options = [];

        foreach ($values as $key => $value) {
            $key = trim((string)$key);
            if ($key === '') {
                continue;
            }

            $type = (string)($types[$key] ?? 'text');

            if ($type === 'boolean') {
                $options[$key] = in_array((string)$value, ['1', 'true', 'on', 'yes'], true);
                continue;
            }

            if (is_array($value)) {
                continue;
            }

            $value = trim((string)$value);
            if ($value === '') {
                continue;
            }

            if ($type === 'number') {
                if (!is_numeric($value)) {
                    return [[], '加密选项“' . $key . '”必须是数字。'];
                }
                $options[$key] = str_contains($value, '.') ? (float)$value : (int)$value;
                continue;
            }

            if ($type === 'json') {
                $decoded = json_decode($value, true);
                if (json_last_error() !== JSON_ERROR_NONE) {
                    return [[], '加密选项“' . $key . '”必须是合法 JSON。'];
                }
                $options[$key] = $decoded;
                continue;
            }

            $options[$key] = $value;
        }

        return [$options, ''];
    }
}
