<?php
declare(strict_types=1);

namespace App\Controller;

use App\Http\Request;
use App\Http\Response;
use App\Murk\MurkApiClient;
use App\Murk\MurkApiException;
use App\Support\Auth;
use App\Support\Flash;
use App\Support\View;

final class AdminController
{
    public function __construct(
        private readonly Auth $auth,
        private readonly MurkApiClient $client,
        private readonly View $view,
    ) {
    }

    public function index(Request $request): void
    {
        if (!$this->auth->check()) {
            Response::redirect('/admin/login');
            return;
        }

        $filters = [
            'page' => max(1, (int)$request->query('page', 1)),
            'limit' => min(50, max(5, (int)$request->query('limit', 10))),
            'scriptName' => trim((string)$request->query('scriptName', '')),
            'ip' => trim((string)$request->query('ip', '')),
            'status' => trim((string)$request->query('status', '')),
            'startTime' => trim((string)$request->query('startTime', '')),
            'endTime' => trim((string)$request->query('endTime', '')),
        ];

        $scripts = ['list' => [], 'total' => 0];
        $tasks = ['list' => [], 'total' => 0, 'page' => $filters['page'], 'limit' => $filters['limit']];
        $statusOptions = [];
        $apiError = '';

        if ($this->client->hasToken()) {
            try {
                $scripts = $this->client->listScripts();
                $statusOptions = $this->client->listStatusOptions();
                $tasks = $this->client->listTasks($filters);
            } catch (MurkApiException $e) {
                $apiError = $e->getMessage();
            }
        } else {
            $apiError = '请先在 .env 中设置 MURK_API_TOKEN。';
        }

        Response::html($this->view->render('admin/dashboard', [
            'apiError' => $apiError,
            'filters' => $filters,
            'flash' => Flash::pull(),
            'scripts' => $scripts,
            'statusOptions' => $statusOptions,
            'tasks' => $tasks,
            'adminName' => (string)($_SESSION['admin_username'] ?? 'admin'),
        ]));
    }

    public function show(Request $request, array $vars): void
    {
        if (!$this->auth->check()) {
            Response::redirect('/admin/login');
            return;
        }

        $taskId = (string)($vars['id'] ?? '');

        try {
            Response::html($this->view->render('task', [
                'task' => $this->client->getTask($taskId),
                'taskId' => $taskId,
                'flash' => Flash::pull(),
                'backUrl' => '/admin',
            ]));
        } catch (MurkApiException $e) {
            Flash::put('error', $e->getMessage());
            Response::redirect('/admin');
        }
    }
}
