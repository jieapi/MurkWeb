<?php
declare(strict_types=1);

namespace App\Controller;

use App\Http\Request;
use App\Http\Response;
use App\Support\Auth;
use App\Support\Csrf;
use App\Support\Flash;
use App\Support\View;

final class AuthController
{
    public function __construct(
        private readonly Auth $auth,
        private readonly View $view,
    ) {
    }

    public function loginForm(Request $request): void
    {
        if ($this->auth->check()) {
            Response::redirect('/admin');
            return;
        }

        Response::html($this->view->render('admin/login', [
            'flash' => Flash::pull(),
            'csrfToken' => Csrf::token(),
        ]));
    }

    public function login(Request $request): void
    {
        if (!Csrf::validate((string)$request->post('csrf_token', ''))) {
            Flash::put('error', '页面已过期，请刷新后重试。');
            Response::redirect('/admin/login');
            return;
        }

        $username = trim((string)$request->post('username', ''));
        $password = (string)$request->post('password', '');

        if (!$this->auth->attempt($username, $password)) {
            Flash::put('error', '账号或密码错误。');
            Response::redirect('/admin/login');
            return;
        }

        Response::redirect('/admin');
    }

    public function logout(Request $request): void
    {
        $this->auth->logout();
        Flash::put('success', '已退出后台。');
        Response::redirect('/admin/login');
    }
}
