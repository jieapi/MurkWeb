<?php
declare(strict_types=1);

namespace App\Murk;

use RuntimeException;

final class MurkApiException extends RuntimeException
{
}
