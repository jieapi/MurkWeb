<?php
declare(strict_types=1);

namespace App\Murk;

use CURLFile;

final class MurkApiClient
{
    public function __construct(
        private readonly string $baseUrl,
        private readonly string $token,
    ) {
    }

    public function hasToken(): bool
    {
        return $this->token !== '';
    }

    public function listScripts(int $page = 1, int $limit = 50): array
    {
        return $this->request('GET', '/api/v1/encrypt/scripts', [
            'query' => ['page' => $page, 'limit' => $limit],
        ]);
    }

    public function uploadSource(string $scriptCode, array $file): array
    {
        if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            throw new MurkApiException('请上传 PHP 文件或 ZIP 源码包。');
        }

        $tmpName = (string)($file['tmp_name'] ?? '');
        if ($tmpName === '' || !is_uploaded_file($tmpName)) {
            throw new MurkApiException('上传文件无效。');
        }

        return $this->request('POST', '/api/v1/encrypt/upload', [
            'multipart' => [
                'scriptCode' => $scriptCode,
                'file' => new CURLFile(
                    $tmpName,
                    (string)($file['type'] ?? 'application/octet-stream'),
                    (string)($file['name'] ?? 'source.zip'),
                ),
            ],
        ]);
    }

    public function createTask(string $scriptCode, string $fileId, array $options = []): array
    {
        return $this->request('POST', '/api/v1/encrypt/tasks', [
            'json' => [
                'scriptCode' => $scriptCode,
                'fileId' => $fileId,
                'options' => $options,
            ],
        ]);
    }

    public function listTasks(array $filters = []): array
    {
        return $this->request('GET', '/api/v1/encrypt/tasks', [
            'query' => array_filter($filters, static fn ($value) => $value !== null && $value !== ''),
        ]);
    }

    public function listStatusOptions(): array
    {
        return $this->request('GET', '/api/v1/encrypt/tasks/status-options');
    }

    public function getTask(string $taskId): array
    {
        return $this->request('GET', '/api/v1/encrypt/tasks/' . rawurlencode($taskId));
    }

    public function downloadUrl(array $task): ?string
    {
        $url = (string)($task['downloadUrl'] ?? '');

        return str_starts_with($url, $this->baseUrl . '/') ? $url : null;
    }

    private function request(string $method, string $path, array $options = []): array
    {
        if (!$this->hasToken()) {
            throw new MurkApiException('请先在 .env 中设置 MURK_API_TOKEN。');
        }

        $url = $this->baseUrl . $path;
        if (!empty($options['query'])) {
            $url .= '?' . http_build_query($options['query']);
        }

        $headers = [
            'Accept: application/json',
            'Authorization: Bearer ' . $this->token,
        ];

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_TIMEOUT => 45,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
        ]);

        if (isset($options['json'])) {
            $payload = json_encode($options['json'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            $headers[] = 'Content-Type: application/json';
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        } elseif (isset($options['multipart'])) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $options['multipart']);
        }

        $body = curl_exec($ch);
        $error = curl_error($ch);
        $status = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);

        if ($body === false) {
            throw new MurkApiException('请求开放 API 失败：' . $error);
        }

        $decoded = json_decode((string)$body, true);
        if (!is_array($decoded)) {
            throw new MurkApiException('开放 API 返回了非 JSON 响应，HTTP 状态码：' . $status);
        }

        $code = (int)($decoded['code'] ?? $status);
        if ($status >= 400 || $code !== 200) {
            $message = (string)($decoded['message'] ?? '开放 API 业务处理失败。');
            throw new MurkApiException($message);
        }

        return is_array($decoded['data'] ?? null) ? $decoded['data'] : [];
    }
}
