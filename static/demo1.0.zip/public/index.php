<?php
declare(strict_types=1);

use App\Config;
use App\Controller\AdminController;
use App\Controller\AuthController;
use App\Controller\FrontController;
use App\Http\Request;
use App\Http\Response;
use App\Murk\MurkApiClient;
use App\Support\Auth;
use App\Support\View;
use Dotenv\Dotenv;
use FastRoute\RouteCollector;
use function FastRoute\simpleDispatcher;

$root = dirname(__DIR__);

require $root . '/vendor/autoload.php';
require $root . '/src/Support/helpers.php';

Dotenv::createImmutable($root)->safeLoad();
session_start();

$request = Request::capture();
$config = new Config([]);
$view = new View($root . '/views', $config->site());
$client = new MurkApiClient($config->apiBaseUrl(), $config->apiToken());
$auth = new Auth($config);
$frontController = new FrontController($client, $view);
$authController = new AuthController($auth, $view);
$adminController = new AdminController($auth, $client, $view);

$dispatcher = simpleDispatcher(static function (RouteCollector $routes): void {
    $routes->addRoute('GET', '/', 'front.index');
    $routes->addRoute('POST', '/encrypt/upload', 'front.upload');
    $routes->addRoute('POST', '/encrypt/tasks', 'front.create');
    $routes->addRoute('GET', '/tasks/{id:\d+}', 'front.show');
    $routes->addRoute('GET', '/tasks/{id:\d+}/download', 'front.download');
    $routes->addRoute('GET', '/encrypt/tasks/{id:\d+}/status', 'front.status');

    $routes->addRoute('GET', '/admin', 'admin.index');
    $routes->addRoute('GET', '/admin/tasks/{id:\d+}', 'admin.show');
    $routes->addRoute('GET', '/admin/login', 'auth.loginForm');
    $routes->addRoute('POST', '/admin/login', 'auth.login');
    $routes->addRoute('GET', '/admin/logout', 'auth.logout');
});

$routeInfo = $dispatcher->dispatch($request->method(), $request->path());

switch ($routeInfo[0]) {
    case FastRoute\Dispatcher::NOT_FOUND:
        Response::html('页面不存在', 404);
        break;

    case FastRoute\Dispatcher::METHOD_NOT_ALLOWED:
        Response::html('请求方法不允许', 405);
        break;

    case FastRoute\Dispatcher::FOUND:
        $handler = $routeInfo[1];
        $vars = $routeInfo[2];

        match ($handler) {
            'front.index' => $frontController->index($request),
            'front.upload' => $frontController->upload($request),
            'front.create' => $frontController->create($request),
            'front.show' => $frontController->show($request, $vars),
            'front.download' => $frontController->download($request, $vars),
            'front.status' => $frontController->status($request, $vars),
            'admin.index' => $adminController->index($request),
            'admin.show' => $adminController->show($request, $vars),
            'auth.loginForm' => $authController->loginForm($request),
            'auth.login' => $authController->login($request),
            'auth.logout' => $authController->logout($request),
        };
        break;
}
